Title: Wisdom Quotes Text Database ( More Than 5500 Quotes For Free Use )
Description: A Quotes Text Database Application Displaying More Than 5500 Quotes From Various Categories And Authors . You Can Use it to Build Quote of the day Applications Plus ADDED a Php Source Code For Web Based Quote Of The Day Readymade.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=65205&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
