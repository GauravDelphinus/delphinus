Welcome

Your Had Downloaded The Quotes Software Which Have a Text Database File Having More Than
5500 Quotes

Included a Php File To Use With The Quotes.txt as a Web Based Quote of The Day System .



Author :
Ajay Sudhera
@ AjayWarez

Email : ajay_bnl@yahoo.com
Website : Http://Geocities.com/ajay_bnl

