To run:
1. Open the before or after directory on the command line
2. Type "npm install"
3. Type "gulp"
4. If your browser doesn't open automatically, load http://localhost:9005